<?php
session_start();
echo "<h2>Current Session Data:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

if (isset($_SESSION['user_id'])) {
    echo "<h3>User ID: " . $_SESSION['user_id'] . "</h3>";
    echo "<h3>User Type: " . $_SESSION['user_type'] . "</h3>";
    echo "<h3>User Name: " . $_SESSION['user_name'] . "</h3>";
} else {
    echo "<h3>No user logged in</h3>";
}
?> <?php
session_start();
echo "<h2>Current Session Data:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

if (isset($_SESSION['user_id'])) {
    echo "<h3>User ID: " . $_SESSION['user_id'] . "</h3>";
    echo "<h3>User Type: " . $_SESSION['user_type'] . "</h3>";
    echo "<h3>User Name: " . $_SESSION['user_name'] . "</h3>";
} else {
    echo "<h3>No user logged in</h3>";
}
?> 