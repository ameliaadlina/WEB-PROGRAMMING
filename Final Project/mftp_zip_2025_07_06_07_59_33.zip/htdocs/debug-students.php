<?php
include_once 'db.php';

echo "<h2>All Students in Database:</h2>";
$result = $conn->query("SELECT id, name, email FROM users ORDER BY id");
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Name</th><th>Email</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['email']}</td></tr>";
}
echo "</table>";

echo "<h2>All Employers in Database:</h2>";
$result = $conn->query("SELECT id, name, email FROM employers ORDER BY id");
echo "<table border='1'>";
echo "<tr><th>ID</th><th>Name</th><th>Email</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['email']}</td></tr>";
}
echo "</table>";
?> 